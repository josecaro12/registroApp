export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyDJKuip9IHdD8Wme3XnKDaw2_n-6XYSAF0",
    authDomain: "p-s-auth.firebaseapp.com",
    projectId: "p-s-auth",
    storageBucket: "p-s-auth.appspot.com",
    messagingSenderId: "344904620943",
    appId: "1:344904620943:web:03a8e3c0c710666d86c9fa"
  }
};
